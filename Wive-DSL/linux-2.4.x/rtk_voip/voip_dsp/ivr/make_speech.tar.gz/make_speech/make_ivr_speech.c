#include <stdio.h>

#define FILE_PATH			"./res/"
#define ARRAY_PREFIX		"ivr_wave_"

#define _M_FILE( x )	{ FILE_PATH #x ".snd", ARRAY_PREFIX #x }
struct {
	const unsigned char *pFilename;
	const unsigned char *pArrayName;
} speech_files[] = {
	_M_FILE( number_0 ),
	_M_FILE( number_1 ),
	_M_FILE( number_2 ),
	_M_FILE( number_3 ),
	_M_FILE( number_4 ),
	_M_FILE( number_5 ),
	_M_FILE( number_6 ),
	_M_FILE( number_7 ),
	_M_FILE( number_8 ),
	_M_FILE( number_9 ),
	_M_FILE( number_dot ),
	_M_FILE( alphabet_a ),
	_M_FILE( alphabet_b ),
	_M_FILE( alphabet_c ),
	_M_FILE( alphabet_d ),
	_M_FILE( alphabet_e ),
	_M_FILE( alphabet_f ),
	_M_FILE( alphabet_g ),
	_M_FILE( alphabet_h ),
	_M_FILE( alphabet_i ),
	_M_FILE( alphabet_j ),
	_M_FILE( alphabet_k ),
	_M_FILE( alphabet_l ),
	_M_FILE( alphabet_m ),
	_M_FILE( alphabet_n ),
	_M_FILE( alphabet_o ),
	_M_FILE( alphabet_p ),
	_M_FILE( alphabet_q ),
	_M_FILE( alphabet_r ),
	_M_FILE( alphabet_s ),
	_M_FILE( alphabet_t ),
	_M_FILE( alphabet_u ),
	_M_FILE( alphabet_v ),
	_M_FILE( alphabet_w ),
	_M_FILE( alphabet_x ),
	_M_FILE( alphabet_y ),
	_M_FILE( alphabet_z ),
	_M_FILE( text_DHCP ),
	_M_FILE( text_fixIP ),
	_M_FILE( text_no_resource ),
	//_M_FILE( text_xxx ),
};
#undef _M_FILE

#define NUM_OF_SPEECH_FILES		( sizeof( speech_files ) / sizeof( speech_files[ 0 ] ) )

#define FILENAME_DEST			"ivr_speech.c"

#define FILE_HEADER	"#include \"rtk_voip.h\"\n#include \"ivr.h\"\n#include \"voip_params.h\"\n\n"
#define FILE_TAIL	"#include \"ivr_speech_table.c\"\n"

extern unsigned char linear2alaw(int pcm_val);

inline short toLittleEndian( short val )
{
	union {
		short val;
		struct {
			unsigned char v1;
			unsigned char v2;
		};
	} v;
	unsigned char t;
	
	v.val = val;
	
	t = v.v1;
	v.v1 = v.v2;
	v.v2 = t;
	
	return v.val;
}

int main()
{
	FILE *fpSrc, *fpDest;
	short pcm[ 16 ];
	unsigned char buffer[ 16 ];
	int i, j;

	if( ( fpDest = fopen( FILENAME_DEST, "w" ) ) == 0 ) {
		printf( "Can't open " FILENAME_DEST "\n" );
		return 0;
	}
	
	fputs( FILE_HEADER, fpDest );
	
	for( j = 0; j < NUM_OF_SPEECH_FILES; j ++ ) {
	
		if( ( fpSrc = fopen( speech_files[ j ].pFilename, "rb" ) ) == 0 ) {
			printf( "Can't open %s\n", speech_files[ j ].pFilename );
			break;
		}
		
		/* round 1: generate G711 data */
		fputs( "#ifdef _IVR_711A_SPEECH\n", fpDest );		/* #ifdef */
		
		fprintf( fpDest, "const unsigned char %s[] = {\n", speech_files[ j ].pArrayName );
		
		while( fread( pcm, 10, 2, fpSrc ) == 2 ) {	/* discard tail fraction */
			
			for( i = 0; i < 10; i ++ )
				buffer[ i ] = linear2alaw( toLittleEndian( pcm[ i ] ) );
		
			fprintf( fpDest, "0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, \n",
					 buffer[ 0 ], buffer[ 1 ], buffer[ 2 ], buffer[ 3 ], buffer[ 4 ], 
					 buffer[ 5 ], buffer[ 6 ], buffer[ 7 ], buffer[ 8 ], buffer[ 9 ] );
		}
		
		fputs( "};\n", fpDest );
		
		/* round 2: generate PCM data */
		fputs( "#else\n", fpDest );							/* #else */
		fprintf( fpDest, "const unsigned char %s[] = {\n", speech_files[ j ].pArrayName );
		
		fseek( fpSrc, 0, SEEK_SET );
		
		while( fread( buffer, 10, 1, fpSrc ) == 1 ) {	/* discard tail fraction */
			fprintf( fpDest, "0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, \n",
					 buffer[ 0 ], buffer[ 1 ], buffer[ 2 ], buffer[ 3 ], buffer[ 4 ], 
					 buffer[ 5 ], buffer[ 6 ], buffer[ 7 ], buffer[ 8 ], buffer[ 9 ] );
		}
		
		fputs( "};\n", fpDest );		
		fputs( "#endif\n\n", fpDest );						/* #endif */
		
		fclose( fpSrc );
	}

	fputs( FILE_TAIL, fpDest );
	
	fclose( fpDest );
	
	printf( "Copy " FILENAME_DEST " to IVR directory.\n" );
	
	return 1;
}

///////////////////////////////////////////////////////////////////////////////
// Follows are copied from 711.c
//
#define	SEG_SHIFT		(4)			/* Left shift for segment number. */
#define	QUANT_MASK		(0xf)		/* Quantization field mask. */

static int search(int val, short *table, int size)
{
	int     i;

	for (i = 0; i < size; i++) 
	{
		if (val <= *table++)
 			return (i);
    }
	return (size);
}

/*
 * linear2alaw() - Convert a 16-bit linear PCM value to 8-bit A-law
 *
 * linear2alaw() accepts an 16-bit integer and encodes it as A-law data.
 *
 *      Linear Input Code   Compressed Code
 *  ------------------------    ---------------
 *  0000000wxyza            000wxyz
 *  0000001wxyza            001wxyz
 *  000001wxyzab            010wxyz
 *  00001wxyzabc            011wxyz
 *  0001wxyzabcd            100wxyz
 *  001wxyzabcde            101wxyz
 *  01wxyzabcdef            110wxyz
 *  1wxyzabcdefg            111wxyz
 */
static  unsigned short	seg_end[8] = {0xFF, 0x1FF, 0x3FF, 0x7FF, 0xFFF, 0x1FFF, 0x3FFF, 0x7FFF};
unsigned char linear2alaw(int pcm_val)        /* 2's complement (16-bit range) */
{
	int     mask;
	int     seg;
	unsigned char   aval;

	if (pcm_val >= 0) 
	{
		mask = 0xD5;        /* sign (7th) bit = 1 */
	} 
	else 
	{
		mask = 0x55;        /* sign bit = 0 */        
		pcm_val = ~pcm_val;			
    }

	/* Convert the scaled magnitude to segment number. */
	seg = search(pcm_val, seg_end, 8);

	/* Combine the sign, segment, and quantization bits. */

	if (seg >= 8)       /* out of range, return maximum value. */
		return (0x7F ^ mask);
	else 
	{
		aval = seg << SEG_SHIFT;
		if (seg < 2)
			aval |= (pcm_val >> 4) & QUANT_MASK;
		else
			aval |= (pcm_val >> (seg + 3)) & QUANT_MASK;
		return (aval ^ mask);
    }
}

